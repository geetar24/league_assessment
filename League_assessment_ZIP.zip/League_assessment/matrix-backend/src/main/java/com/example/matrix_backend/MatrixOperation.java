package com.example.matrix_backend;

import java.util.Arrays;
import java.util.stream.Collectors;

public enum MatrixOperation {
    ECHO {
        public String process(int[][] matrix) {
            StringBuilder sb = new StringBuilder();
            for (int[] row : matrix) {
                sb.append(Arrays.toString(row)
                    .replace("[", "")
                    .replace("]", "")
                    .replace(" ", ""))
                  .append("\n");
            }
            return sb.toString().trim();
        }
    },
    INVERT {
        public String process(int[][] matrix) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < matrix[0].length; i++) {
                for (int j = 0; j < matrix.length; j++) {
                    sb.append(matrix[j][i]);
                    if (j < matrix.length - 1) sb.append(",");
                }
                if (i < matrix[0].length - 1) sb.append("\n");
            }
            return sb.toString();
        }
    },
    FLATTEN {
        public String process(int[][] matrix) {
            return Arrays.stream(matrix)
                .flatMapToInt(Arrays::stream)
                .mapToObj(String::valueOf)
                .collect(Collectors.joining(","));
        }
    },
    SUM {
        public String process(int[][] matrix) {
            return String.valueOf(Arrays.stream(matrix)
                .flatMapToInt(Arrays::stream)
                .sum());
        }
    },
    MULTIPLY {
        public String process(int[][] matrix) {
            return String.valueOf(Arrays.stream(matrix)
                .flatMapToInt(Arrays::stream)
                .asLongStream()
                .reduce(1, (a, b) -> a * b));
        }
    };

    public abstract String process(int[][] matrix);
}