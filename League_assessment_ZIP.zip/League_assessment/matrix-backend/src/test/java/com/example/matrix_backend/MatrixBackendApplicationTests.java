package com.example.matrix_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatrixBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
