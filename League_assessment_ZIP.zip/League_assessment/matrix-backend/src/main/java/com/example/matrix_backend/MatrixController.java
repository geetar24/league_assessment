package com.example.matrix_backend;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.util.Arrays;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api")
public class MatrixController {

    @PostMapping("/echo")
    public String echo(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.ECHO.process(parseCSV(file));
    }

    @PostMapping("/invert")
    public String invert(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.INVERT.process(parseCSV(file));
    }

    @PostMapping("/flatten")
    public String flatten(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.FLATTEN.process(parseCSV(file));
    }

    @PostMapping("/sum")
    public String sum(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.SUM.process(parseCSV(file));
    }

    @PostMapping("/multiply")
    public String multiply(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.MULTIPLY.process(parseCSV(file));
    }

    private int[][] parseCSV(MultipartFile file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            return reader.lines()
                .map(line -> Arrays.stream(line.split(","))
                    .mapToInt(Integer::parseInt)
                    .toArray())
                .toArray(int[][]::new);
        }
    }
}