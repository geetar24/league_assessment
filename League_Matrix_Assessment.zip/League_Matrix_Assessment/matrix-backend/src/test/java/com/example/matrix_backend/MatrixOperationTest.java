package com.example.matrix_backend;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixOperationTest {

    private final int[][] testMatrix = {
        {1, 2},
        {3, 4}
    };

    @Test
    void echo_ReturnsOriginalMatrix() {
        String result = MatrixOperation.ECHO.process(testMatrix);
        assertEquals("1,2\n3,4", result);
    }

    @Test
    void invert_ReturnsTransposedMatrix() {
        String result = MatrixOperation.INVERT.process(testMatrix);
        assertEquals("1,3\n2,4", result);
    }

    @Test
    void flatten_ReturnsCommaSeparatedValues() {
        String result = MatrixOperation.FLATTEN.process(testMatrix);
        assertEquals("1,2,3,4", result);
    }

    @Test
    void sum_ReturnsCorrectTotal() {
        String result = MatrixOperation.SUM.process(testMatrix);
        assertEquals("10", result);
    }

    @Test
    void multiply_ReturnsCorrectProduct() {
        String result = MatrixOperation.MULTIPLY.process(testMatrix);
        assertEquals("24", result);
    }

    @Test
    void emptyMatrix_ReturnsEmptyStringForEcho() {
        int[][] emptyMatrix = {};
        String result = MatrixOperation.ECHO.process(emptyMatrix);
        assertEquals("", result);
    }
}