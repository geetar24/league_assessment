package com.example.matrix_backend;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.util.Arrays;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", 
             allowedHeaders = "*", 
             methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.OPTIONS},
             maxAge = 3600)
public class MatrixController {

    @PostMapping(value = "/echo", produces = "text/plain")
    public String echo(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.ECHO.process(parseCSV(file));
    }

    @PostMapping(value = "/invert", produces = "text/plain")
    public String invert(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.INVERT.process(parseCSV(file));
    }

    @PostMapping(value = "/flatten", produces = "text/plain")
    public String flatten(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.FLATTEN.process(parseCSV(file));
    }

    @PostMapping(value = "/sum", produces = "text/plain")
    public String sum(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.SUM.process(parseCSV(file));
    }

    @PostMapping(value = "/multiply", produces = "text/plain")
    public String multiply(@RequestParam("file") MultipartFile file) throws IOException {
        return MatrixOperation.MULTIPLY.process(parseCSV(file));
    }

    private int[][] parseCSV(MultipartFile file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            return reader.lines()
                .map(line -> Arrays.stream(line.split(","))
                    .mapToInt(Integer::parseInt)
                    .toArray())
                .toArray(int[][]::new);
        }
    }

    // Add this to handle preflight OPTIONS requests
    @RequestMapping(method = RequestMethod.OPTIONS, value = "/**")
    public ResponseEntity<?> handleOptions() {
        return ResponseEntity.ok()
            .header("Access-Control-Allow-Origin", "*")
            .header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
            .header("Access-Control-Allow-Headers", "*")
            .build();
    }
}