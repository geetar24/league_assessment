import React, { useState } from 'react';
import './App.css';

function App() {
  const [file, setFile] = useState(null);
  const [operation, setOperation] = useState('echo');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return;

    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch(`http://localhost:8081/api/${operation}`, {
        method: 'POST',
        body: formData
      });
      const data = operation === 'sum' || operation === 'multiply' 
        ? await response.json() 
        : await response.text();
      setResult(data);
    } catch (err) {
      setResult(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Matrix Processor</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="file"
          accept=".csv"
          onChange={(e) => setFile(e.target.files[0])}
          required
        />
        <select 
          value={operation} 
          onChange={(e) => setOperation(e.target.value)}
        >
          <option value="echo">Echo</option>
          <option value="invert">Invert</option>
          <option value="flatten">Flatten</option>
          <option value="sum">Sum</option>
          <option value="multiply">Multiply</option>
        </select>
        <button type="submit" disabled={loading}>
          {loading ? 'Processing...' : 'Submit'}
        </button>
      </form>
      <div className="result-container">
        <h3>Result:</h3>
        <pre>{typeof result === 'object' ? JSON.stringify(result) : result}</pre>
      </div>
    </div>
  );
}

export default App;