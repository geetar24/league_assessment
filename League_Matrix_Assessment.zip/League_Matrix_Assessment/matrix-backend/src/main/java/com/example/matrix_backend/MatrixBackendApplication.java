package com.example.matrix_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatrixBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(MatrixBackendApplication.class, args);
    }
}