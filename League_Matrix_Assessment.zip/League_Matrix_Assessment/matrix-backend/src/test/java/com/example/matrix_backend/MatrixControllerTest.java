package com.example.matrix_backend;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class MatrixControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private MockMultipartFile createTestFile(String content) {
        return new MockMultipartFile(
            "file",
            "matrix.csv",
            "text/csv",
            content.getBytes()
        );
    }

    @Test
    void echo_ValidMatrix_ReturnsEchoedMatrix() throws Exception {
        MockMultipartFile file = createTestFile("1,2\n3,4");
        
        mockMvc.perform(multipart("/api/echo")
                .file(file))
                .andExpect(status().isOk())
                .andExpect(content().string("1,2\n3,4"));
    }

    @Test
    void invert_ValidMatrix_ReturnsInvertedMatrix() throws Exception {
        MockMultipartFile file = createTestFile("1,2\n3,4");
        
        mockMvc.perform(multipart("/api/invert")
                .file(file))
                .andExpect(status().isOk())
                .andExpect(content().string("1,3\n2,4"));
    }

    @Test
    void invalidFile_ReturnsBadRequest() throws Exception {
        MockMultipartFile file = createTestFile("1,a\n3,4");
        
        mockMvc.perform(multipart("/api/sum")
                .file(file))
                .andExpect(status().isBadRequest());
    }
}